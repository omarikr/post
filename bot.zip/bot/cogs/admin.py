import discord
from discord.ext import commands
from bot.config import Config
from bot.database import get_db
from bot.node_manager import NodeManager
from bot.credits import CreditsManager
from bot.utils.embeds import Embeds
from bot.utils.security import Security

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # admin-addnode command removed - using hardcoded node configuration

    @commands.hybrid_group(name="admin-credit", description="Manage user credits")
    async def admin_credit(self, ctx: commands.Context):
        if ctx.invoked_subcommand is None:
            await ctx.send("Use `/admin-credit add` or `/admin-credit remove`", ephemeral=True)

    @admin_credit.command(name="add", description="Add credits to a user")
    async def credit_add(self, ctx: commands.Context, user: discord.User, amount: float):
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)
        await CreditsManager.add_credits(user.id, amount)
        await ctx.send(embed=Embeds.success("Credits Added", f"Added ${amount} to {user.mention}'s account."), ephemeral=True)

    @admin_credit.command(name="remove", description="Remove credits from a user")
    async def credit_remove(self, ctx: commands.Context, user: discord.User, amount: float):
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)

        current_bal = await CreditsManager.get_balance(user.id)
        new_bal = max(0.0, current_bal - amount)

        db = await get_db()
        await db.execute("UPDATE users SET balance = ? WHERE id = ?", (new_bal, user.id))
        await db.execute(
            "INSERT INTO transactions (user_id, amount, currency, status, payment_id) VALUES (?, ?, ?, ?, ?)",
            (user.id, -amount, "USD", "admin_remove", "admin")
        )
        await db.commit()
        await ctx.send(embed=Embeds.success("Credits Removed", f"Removed ${amount} from {user.mention}. New Balance: ${new_bal:.2f}"), ephemeral=True)

    @commands.hybrid_command(name="admin-listvps", description="List all VPS instances in the system")
    async def admin_listvps(self, ctx: commands.Context):
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)

        db = await get_db()
        async with db.execute("SELECT id, user_id, lxc_id, plan_name, status FROM vps_instances") as cursor:
            rows = await cursor.fetchall()

        embed = discord.Embed(title="Global VPS Instances", color=discord.Color.dark_grey())
        if not rows:
            embed.description = "No VPS instances found."
        for row in rows:
            embed.add_field(
                name=f"ID: {row[0]} | User: {row[1]}",
                value=f"LXC: {row[2]} | Plan: {row[3]} | Status: {row[4]}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)

    # Moderation Commands
    @commands.hybrid_command(name="kick", description="Kick a user from the server")
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx: commands.Context, user: discord.Member, *, reason: str = "No reason provided"):
        if user.top_role >= ctx.author.top_role and ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("You cannot kick someone with a higher or equal role.", ephemeral=True)
        
        try:
            await user.kick(reason=reason)
            await ctx.send(embed=Embeds.success("User Kicked", f"{user.mention} has been kicked.\n**Reason:** {reason}"))
        except Exception as e:
            await ctx.send(embed=Embeds.error("Kick Failed", str(e)), ephemeral=True)

    @commands.hybrid_command(name="ban", description="Ban a user from the server")
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx: commands.Context, user: discord.User, *, reason: str = "No reason provided"):
        try:
            await ctx.guild.ban(user, reason=reason)
            await ctx.send(embed=Embeds.success("User Banned", f"{user.mention} has been banned.\n**Reason:** {reason}"))
        except Exception as e:
            await ctx.send(embed=Embeds.error("Ban Failed", str(e)), ephemeral=True)

    @commands.hybrid_command(name="timeout", description="Timeout a user for a specified duration")
    @commands.has_permissions(moderate_members=True)
    async def timeout(self, ctx: commands.Context, user: discord.Member, duration: str, *, reason: str = "No reason provided"):
        if user.top_role >= ctx.author.top_role and ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("You cannot timeout someone with a higher or equal role.", ephemeral=True)
        
        # Parse duration (e.g., "10m", "1h", "1d")
        duration_map = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
        unit = duration[-1].lower()
        if unit not in duration_map:
            return await ctx.send("Invalid duration format. Use e.g., 10s, 10m, 1h, 1d", ephemeral=True)
        
        try:
            seconds = int(duration[:-1]) * duration_map[unit]
            await user.timeout(discord.utils.utcnow() + discord.timedelta(seconds=seconds), reason=reason)
            await ctx.send(embed=Embeds.success("User Timed Out", f"{user.mention} has been timed out for {duration}.\n**Reason:** {reason}"))
        except Exception as e:
            await ctx.send(embed=Embeds.error("Timeout Failed", str(e)), ephemeral=True)

    @commands.hybrid_command(name="lock", description="Lock the current channel")
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx: commands.Context):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(embed=Embeds.success("Channel Locked", "This channel has been locked."))

    @commands.hybrid_command(name="unlock", description="Unlock the current channel")
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx: commands.Context):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(embed=Embeds.success("Channel Unlocked", "This channel has been unlocked."))

    @commands.hybrid_command(name="hide", description="Hide the current channel from everyone")
    @commands.has_permissions(manage_channels=True)
    async def hide(self, ctx: commands.Context):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.view_channel = False
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(embed=Embeds.success("Channel Hidden", "This channel has been hidden from everyone."), ephemeral=True)

    @commands.hybrid_command(name="unhide", description="Unhide the current channel")
    @commands.has_permissions(manage_channels=True)
    async def unhide(self, ctx: commands.Context):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.view_channel = None
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(embed=Embeds.success("Channel Unhidden", "This channel is now visible."), ephemeral=True)

    @commands.hybrid_command(name="purge", description="Delete a specified number of messages")
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx: commands.Context, amount: int):
        if amount < 1 or amount > 100:
            return await ctx.send("Amount must be between 1 and 100.", ephemeral=True)
        
        try:
            deleted = await ctx.channel.purge(limit=amount + 1)  # +1 to include the command message
            await ctx.send(embed=Embeds.success("Messages Purged", f"Deleted {len(deleted) - 1} messages."), ephemeral=True)
        except Exception as e:
            await ctx.send(embed=Embeds.error("Purge Failed", str(e)), ephemeral=True)

async def setup(bot):
    await bot.add_cog(AdminCog(bot))
