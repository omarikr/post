import discord
from discord import app_commands
from discord.ext import commands
from bot.config import Config
from bot.credits import CreditsManager
from bot.database import get_db
from bot.lxc_manager import LXCManager
from bot.node_manager import NodeManager
from bot.utils.embeds import Embeds
import random
import string
import asyncio
import jwt
import datetime

# ────────────────────────────────────────────────────────────────────────────
#  Loading helper
# ────────────────────────────────────────────────────────────────────────────
class _LoadingView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(discord.ui.Button(
            label="Please wait...",
            style=discord.ButtonStyle.secondary,
            disabled=True
        ))


async def _loading(interaction: discord.Interaction, title: str, desc: str):
    embed = discord.Embed(
        title=title,
        description=desc,
        color=discord.Color.from_rgb(255, 165, 0)
    )
    embed.set_footer(text="This may take up to a minute — please don't close this window.")
    try:
        await interaction.edit_original_response(embed=embed, view=_LoadingView())
    except Exception:
        pass


# ────────────────────────────────────────────────────────────────────────────
#  Deploy embed helper
# ────────────────────────────────────────────────────────────────────────────
def _build_deploy_embed(plan: str | None, os_label: str | None, ipv6: bool) -> discord.Embed:
    lines = [
        f"**Plan:**  {('`' + plan + '`') if plan else 'Not selected'}",
        f"**OS:**    {os_label if os_label else 'Not selected'}",
        f"**IPv6:**  {'Enabled (+$1/mo)' if ipv6 else 'Disabled'}",
        "",
        "Select a Plan and OS, then click **Deploy VPS**.",
    ]
    return discord.Embed(
        title="Deploy a VPS",
        description="\n".join(lines),
        color=discord.Color.blurple()
    )


# ────────────────────────────────────────────────────────────────────────────
#  Dynamic VPS creation view  (plan + OS + IPv6 + deploy)
# ────────────────────────────────────────────────────────────────────────────
class VPSView(discord.ui.View):
    def __init__(self, bot, user_id: int, node: dict, templates: list[dict]):
        super().__init__(timeout=120)
        self.bot      = bot
        self.user_id  = user_id
        self.node     = node
        self.plan     = None
        self.template = None
        self.os_label = None
        self.ipv6     = False

        # Plan dropdown
        plan_select = discord.ui.Select(
            custom_id="plan_select",
            placeholder="Choose a Plan",
            options=[
                discord.SelectOption(
                    label=name,
                    value=name,
                    description=(
                        f"{data['cpu']} vCPU  {data['ram']}MB RAM  "
                        f"{data['disk']}GB Disk  ${data['price']}/mo"
                    )
                )
                for name, data in Config.PLANS.items()
            ],
            row=0
        )
        plan_select.callback = self._on_plan
        self.add_item(plan_select)

        # OS dropdown
        if templates:
            os_options = [
                discord.SelectOption(
                    label=t["label"][:100],
                    value=t["value"][:100],
                    emoji=t["emoji"],
                    description=t["value"].split("/")[-1][:100]
                )
                for t in templates
            ]
        else:
            os_options = [
                discord.SelectOption(
                    label="Ubuntu 22.04 (standard)",
                    value="local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst",
                    description="Default fallback template"
                )
            ]

        os_select = discord.ui.Select(
            custom_id="os_select",
            placeholder="Choose an OS",
            options=os_options,
            row=1
        )
        os_select.callback = self._on_os
        self.add_item(os_select)

        # IPv6 button
        self.ipv6_btn = discord.ui.Button(
            label="Add IPv6 (+$1/mo)",
            style=discord.ButtonStyle.secondary,
            row=2,
            custom_id="ipv6_toggle"
        )
        self.ipv6_btn.callback = self._on_ipv6
        self.add_item(self.ipv6_btn)

        # Deploy button
        deploy_btn = discord.ui.Button(
            label="Deploy VPS",
            style=discord.ButtonStyle.success,
            row=2,
            custom_id="deploy_btn"
        )
        deploy_btn.callback = self._on_deploy
        self.add_item(deploy_btn)

    async def _on_plan(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("This menu is not for you.", ephemeral=True)
        self.plan = interaction.data["values"][0]
        await interaction.response.edit_message(
            embed=_build_deploy_embed(self.plan, self.os_label, self.ipv6), view=self
        )

    async def _on_os(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("This menu is not for you.", ephemeral=True)
        self.template = interaction.data["values"][0]
        for item in self.children:
            if isinstance(item, discord.ui.Select) and item.custom_id == "os_select":
                for opt in item.options:
                    if opt.value == self.template:
                        self.os_label = f"{opt.emoji} {opt.label}" if opt.emoji else opt.label
                        break
                break
        await interaction.response.edit_message(
            embed=_build_deploy_embed(self.plan, self.os_label, self.ipv6), view=self
        )

    async def _on_ipv6(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("This menu is not for you.", ephemeral=True)
        self.ipv6 = not self.ipv6
        self.ipv6_btn.label = "IPv6: Enabled (+$1/mo)" if self.ipv6 else "Add IPv6 (+$1/mo)"
        self.ipv6_btn.style = discord.ButtonStyle.success if self.ipv6 else discord.ButtonStyle.secondary
        await interaction.response.edit_message(
            embed=_build_deploy_embed(self.plan, self.os_label, self.ipv6), view=self
        )

    async def _on_deploy(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("This menu is not for you.", ephemeral=True)
        if not self.plan:
            return await interaction.response.send_message("Please select a plan first.", ephemeral=True)
        if not self.template:
            return await interaction.response.send_message("Please select an OS first.", ephemeral=True)

        plan_data   = Config.PLANS[self.plan]
        total_price = plan_data['price'] + (Config.IPV6_PRICE if self.ipv6 else 0)
        balance     = await CreditsManager.get_balance(self.user_id)

        if balance < total_price:
            return await interaction.response.send_message(
                embed=Embeds.error(
                    "Insufficient Funds",
                    f"You need **${total_price:.2f}** but only have **${balance:.2f}**.\n"
                    f"Use `/deposit` to top up."
                ),
                ephemeral=True
            )

        await interaction.response.defer()
        await _loading(
            interaction,
            "Starting Deployment",
            f"Preparing your **{self.plan}** container with **{self.os_label}**...\n"
            f"IPv6: {'Yes (+$1)' if self.ipv6 else 'No'}  |  Total: **${total_price:.2f}**"
        )

        db = await get_db()

        cursor = await db.execute(
            "INSERT INTO vps_instances (user_id, node_id, plan_name, cpu, ram, disk, "
            "ipv6_enabled, price, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (self.user_id, self.node['id'], self.plan,
             plan_data['cpu'], plan_data['ram'], plan_data['disk'],
             self.ipv6, total_price, "deploying")
        )
        vps_db_id = cursor.lastrowid
        await db.commit()

        await _loading(
            interaction,
            "Creating Container",
            f"Plan: **{self.plan}**  |  OS: **{self.os_label}**\n"
            f"{plan_data['cpu']} vCPU  {plan_data['ram']}MB RAM  {plan_data['disk']}GB Disk\n\n"
            f"Running pct create on Node {self.node['id']}... (30–60 seconds)"
        )

        root_password = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
        success, lxc_id_or_err = await LXCManager.create_lxc(
            self.node, vps_db_id, plan_data, self.ipv6,
            root_password,
            template=self.template
        )

        if success:
            if not await CreditsManager.deduct_credits(self.user_id, total_price):
                await LXCManager.delete_lxc(self.node, lxc_id_or_err)
                await db.execute(
                    "UPDATE vps_instances SET status = ? WHERE id = ?",
                    ("failed_payment", vps_db_id)
                )
                await db.commit()
                return await interaction.edit_original_response(
                    embed=Embeds.error(
                        "Payment Failed",
                        "Balance changed while deploying. "
                        "The container was destroyed and you were not charged."
                    ),
                    view=None
                )

            await db.execute(
                "UPDATE vps_instances SET lxc_id = ?, status = ? WHERE id = ?",
                (lxc_id_or_err, "running", vps_db_id)
            )
            await db.commit()

            try:
                await interaction.user.send(
                    embed=Embeds.success(
                        "VPS Credentials — Save These!",
                        f"**Container ID:** `{lxc_id_or_err}`\n"
                        f"**OS:** {self.os_label}\n"
                        f"**Plan:** {self.plan}\n"
                        f"**Root Password:** `{root_password}`\n\n"
                        f"This is the only time this password is shown."
                    )
                )
                dm_note = "Credentials sent to your DMs."
            except discord.Forbidden:
                dm_note = "**Could not DM you** — enable DMs and contact an admin for your password."

            await interaction.edit_original_response(
                embed=discord.Embed(
                    title="Deployment Complete",
                    description=(
                        f"Your VPS is live on Node **{self.node['id']}**.\n\n"
                        f"**Container ID:** `{lxc_id_or_err}`\n"
                        f"**OS:** {self.os_label}\n"
                        f"**Plan:** {self.plan}  |  "
                        f"{plan_data['cpu']} vCPU  {plan_data['ram']}MB RAM  {plan_data['disk']}GB Disk\n"
                        f"**IPv6:** {'Enabled' if self.ipv6 else 'Disabled'}\n"
                        f"**Charged:** ${total_price:.2f}\n\n"
                        f"{dm_note}"
                    ),
                    color=discord.Color.green()
                ),
                view=None
            )
        else:
            await db.execute(
                "UPDATE vps_instances SET status = ? WHERE id = ?",
                ("failed", vps_db_id)
            )
            await db.commit()
            await interaction.edit_original_response(
                embed=Embeds.error(
                    "Deployment Failed",
                    f"The container could not be created. You were **not charged**.\n\n"
                    f"**Error:**\n```\n{lxc_id_or_err[:1500]}\n```"
                ),
                view=None
            )


# ────────────────────────────────────────────────────────────────────────────
#  Manage existing VPS
# ────────────────────────────────────────────────────────────────────────────
class ManageVPSView(discord.ui.View):
    def __init__(self, bot, user_id, vps_data, node):
        super().__init__(timeout=None)
        self.bot     = bot
        self.user_id = user_id
        self.vps     = vps_data
        self.node    = node

    @discord.ui.button(label="Start", style=discord.ButtonStyle.green)
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("Not your VPS.", ephemeral=True)
        await interaction.response.defer()
        await _loading(interaction, "Starting VPS", f"Sending start command to container `{self.vps['lxc_id']}`...")
        stdout, stderr, code = await LXCManager.start_lxc(self.node, self.vps['lxc_id'])
        output = ((stdout or "") + (stderr or "")).strip()
        if code == 0:
            await interaction.edit_original_response(
                embed=Embeds.success("VPS Started", f"Container `{self.vps['lxc_id']}` is now starting."), view=self)
        else:
            await interaction.edit_original_response(
                embed=Embeds.error("Start Failed", output or "Unknown error"), view=self)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.red)
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("Not your VPS.", ephemeral=True)
        await interaction.response.defer()
        await _loading(interaction, "Stopping VPS", f"Sending stop command to container `{self.vps['lxc_id']}`...")
        stdout, stderr, code = await LXCManager.stop_lxc(self.node, self.vps['lxc_id'])
        output = ((stdout or "") + (stderr or "")).strip()
        if code == 0:
            await interaction.edit_original_response(
                embed=Embeds.success("VPS Stopped", f"Container `{self.vps['lxc_id']}` has been stopped."), view=self)
        else:
            await interaction.edit_original_response(
                embed=Embeds.error("Stop Failed", output or "Unknown error"), view=self)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.blurple)
    async def restart(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("Not your VPS.", ephemeral=True)
        await interaction.response.defer()
        await _loading(interaction, "Restarting VPS", f"Rebooting container `{self.vps['lxc_id']}`...")
        stdout, stderr, code = await LXCManager.restart_lxc(self.node, self.vps['lxc_id'])
        output = ((stdout or "") + (stderr or "")).strip()
        if code == 0:
            await interaction.edit_original_response(
                embed=Embeds.success("VPS Restarted", f"Container `{self.vps['lxc_id']}` is rebooting."), view=self)
        else:
            await interaction.edit_original_response(
                embed=Embeds.error("Restart Failed", output or "Unknown error"), view=self)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger)
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("Not your VPS.", ephemeral=True)
        await interaction.response.defer()
        await _loading(interaction, "Deleting VPS", f"Stopping and destroying container `{self.vps['lxc_id']}`...")
        stdout, stderr, code = await LXCManager.delete_lxc(self.node, self.vps['lxc_id'])
        output = ((stdout or "") + (stderr or "")).strip()
        if code == 0 or code is None:
            db = await get_db()
            await db.execute("DELETE FROM vps_instances WHERE id = ?", (self.vps['db_id'],))
            await db.commit()
            await interaction.edit_original_response(
                embed=Embeds.success("VPS Deleted", f"Container `{self.vps['lxc_id']}` has been destroyed."),
                view=None)
        else:
            await interaction.edit_original_response(
                embed=Embeds.error("Delete Failed", output or "Unknown error"), view=self)

    @discord.ui.button(label="Console", style=discord.ButtonStyle.grey)
    async def console(self, interaction: discord.Interaction, button: discord.ui.Button):
        token = jwt.encode(
            {"vps_id": self.vps['db_id'], "user_id": self.user_id,
             "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=5)},
            Config.CONSOLE_SECRET, algorithm="HS256"
        )
        url = f"http://{Config.CONSOLE_HOST}:{Config.CONSOLE_PORT}/console/{self.vps['db_id']}?token={token}"
        await interaction.response.send_message(
            embed=Embeds.info("Console Link", f"[Click here to open console]({url})\nExpires in 5 minutes."),
            ephemeral=True
        )


# ────────────────────────────────────────────────────────────────────────────
#  VPS list / selection dropdown
# ────────────────────────────────────────────────────────────────────────────
class VPSSelectView(discord.ui.View):
    def __init__(self, bot, user_id, options):
        super().__init__(timeout=120)
        self.bot     = bot
        self.user_id = user_id
        sel = discord.ui.Select(placeholder="Select a VPS to manage", options=options)
        sel.callback = self.select_callback
        self.add_item(sel)

    async def select_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("Not your menu.", ephemeral=True)

        vps_id = int(interaction.data['values'][0])
        await interaction.response.defer()
        await _loading(interaction, "Loading VPS", "Fetching VPS details and current status...")

        db = await get_db()
        async with db.execute("SELECT * FROM vps_instances WHERE id = ?", (vps_id,)) as c:
            vps_row = await c.fetchone()

        vps_data = {
            'db_id':     vps_row[0],
            'user_id':   vps_row[1],
            'node_id':   vps_row[2],
            'lxc_id':    vps_row[3],
            'plan_name': vps_row[4],
            'cpu':       vps_row[5],
            'ram':       vps_row[6],
            'disk':      vps_row[7],
            'ipv6':      vps_row[8],
            'status':    vps_row[10],
        }

        node   = await NodeManager.get_node(db, vps_data['node_id'])
        status = await LXCManager.get_status(node, vps_data['lxc_id'])
        status_dot = {"running": "Online", "stopped": "Offline"}.get(status, "Unknown")

        embed = Embeds.info(
            f"VPS #{vps_data['lxc_id']}",
            f"**Status:** {status_dot}\n"
            f"**Plan:** {vps_data['plan_name']}\n"
            f"**CPU:** {vps_data['cpu']} Core(s)  |  **RAM:** {vps_data['ram']} MB  |  **Disk:** {vps_data['disk']} GB"
        )
        view = ManageVPSView(self.bot, interaction.user.id, vps_data, node)
        await interaction.edit_original_response(embed=embed, view=view)


# ────────────────────────────────────────────────────────────────────────────
#  Cog
# ────────────────────────────────────────────────────────────────────────────
class VPSCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="ping", description="Check bot latency")
    async def ping(self, ctx: commands.Context):
        latency = round(self.bot.latency * 1000)
        await ctx.send(embed=Embeds.info("Pong!", f"Latency: **{latency}ms**"))

    @commands.hybrid_command(name="plans", description="List available VPS plans")
    async def plans(self, ctx: commands.Context):
        embed = discord.Embed(title="Available LXC Plans", color=discord.Color.blue())
        for name, data in Config.PLANS.items():
            embed.add_field(
                name=name,
                value=(
                    f"CPU: {data['cpu']} Core(s)\n"
                    f"RAM: {data['ram']} MB\n"
                    f"Disk: {data['disk']} GB\n"
                    f"Price: ${data['price']}/mo"
                ),
                inline=True
            )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="create", aliases=["purchase"], description="Deploy a new VPS")
    async def create(self, ctx: commands.Context):
        msg = await ctx.send(
            embed=discord.Embed(
                title="Fetching OS Templates...",
                description="Connecting to the Proxmox node to load available CT templates.",
                color=discord.Color.from_rgb(255, 165, 0)
            ),
            view=_LoadingView()
        )

        db    = await get_db()
        nodes = await NodeManager.get_all_nodes(db)

        if not nodes:
            return await msg.edit(
                embed=Embeds.error("No Nodes", "No Proxmox nodes are configured. Contact an admin."),
                view=None
            )

        node      = random.choice(nodes)
        templates = await NodeManager.list_templates(node)

        if not templates:
            await msg.edit(
                embed=discord.Embed(
                    title="Warning: Could Not Fetch Templates",
                    description=(
                        "Could not retrieve OS templates from the node "
                        "(tmate session may be offline or no templates are downloaded).\n\n"
                        "Falling back to default: **Ubuntu 22.04**"
                    ),
                    color=discord.Color.yellow()
                ),
                view=VPSView(self.bot, ctx.author.id, node, [])
            )
        else:
            await msg.edit(
                embed=_build_deploy_embed(None, None, False),
                view=VPSView(self.bot, ctx.author.id, node, templates)
            )

    @commands.hybrid_command(name="myvps", description="List and manage your VPS instances")
    async def myvps(self, ctx: commands.Context):
        user_id = ctx.author.id
        db = await get_db()
        async with db.execute("SELECT * FROM vps_instances WHERE user_id = ?", (user_id,)) as cursor:
            rows = await cursor.fetchall()

        if not rows:
            return await ctx.send(embed=Embeds.info(
                "No VPS Found",
                "You don't have any VPS instances yet. Use `/create` to deploy one."
            ))

        options = [
            discord.SelectOption(
                label=f"VPS #{row[3]} — {row[4]}",
                value=str(row[0]),
                description=f"Plan: {row[4]} | Status: {row[10]}"
            )
            for row in rows
        ]
        view = VPSSelectView(self.bot, user_id, options)
        await ctx.send(
            embed=Embeds.info(
                "Your VPS Instances",
                f"You have **{len(rows)}** VPS instance(s). Select one below to manage it."
            ),
            view=view
        )

    @commands.hybrid_command(name="help", description="Show all available commands")
    async def help(self, ctx: commands.Context):
        embed = discord.Embed(title="VPS Bot Help", color=discord.Color.gold())
        user_cmds = (
            "`/ping` — Check latency\n"
            "`/plans` — List available LXC plans\n"
            "`/create` (or `!purchase`) — Deploy a new VPS\n"
            "`/myvps` — Manage your VPS instances\n"
            "`/balance` — Check credits\n"
            "`/deposit` — Add credits via OxaPay\n"
            "`/transactions` — View transaction history"
        )
        embed.add_field(name="User Commands", value=user_cmds, inline=False)
        admin_cmds = (
            "`/admin-credit add <user> <amount>` — Add credits\n"
            "`/admin-credit remove <user> <amount>` — Remove credits\n"
            "`/admin-listvps` — List all VPS instances"
        )
        embed.add_field(name="Admin Commands", value=admin_cmds, inline=False)
        mod_cmds = (
            "`/kick <user> [reason]` — Kick a user\n"
            "`/ban <user> [reason]` — Ban a user\n"
            "`/timeout <user> <duration> [reason]` — Timeout a user\n"
            "`/lock` — Lock current channel\n"
            "`/unlock` — Unlock current channel\n"
            "`/hide` — Hide current channel\n"
            "`/unhide` — Unhide current channel\n"
            "`/purge <amount>` — Delete messages"
        )
        embed.add_field(name="Moderation Commands", value=mod_cmds, inline=False)
        embed.set_footer(text="Prefix: ! | Slash commands also supported")
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(VPSCog(bot))
