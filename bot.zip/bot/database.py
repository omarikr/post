import aiosqlite
from bot.config import Config
from bot.utils.security import Security

async def init_db():
    async with aiosqlite.connect(Config.DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                credits REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id TEXT PRIMARY KEY,
                user_id INTEGER,
                amount REAL,
                currency TEXT,
                status TEXT,
                txid TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS nodes (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                host       TEXT NOT NULL,
                ssh_port   INTEGER DEFAULT 22,
                username   TEXT NOT NULL,
                encrypted_password TEXT NOT NULL,
                tmate_user TEXT,
                tmate_host TEXT
            )
        """)

        # Migrate existing DB: add tmate columns if they don't exist yet
        try:
            await db.execute("ALTER TABLE nodes ADD COLUMN tmate_user TEXT")
        except Exception:
            pass  # column already exists
        try:
            await db.execute("ALTER TABLE nodes ADD COLUMN tmate_host TEXT")
        except Exception:
            pass  # column already exists

        await db.execute("""
            CREATE TABLE IF NOT EXISTS vps_instances (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER,
                node_id    INTEGER,
                lxc_id     INTEGER,
                plan_name  TEXT,
                cpu        INTEGER,
                ram        INTEGER,
                disk       INTEGER,
                ipv6_enabled BOOLEAN,
                price      REAL,
                status     TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (node_id) REFERENCES nodes (id)
            )
        """)
        
        # Insert hardcoded node if it doesn't exist
        encrypted_pass = Security.encrypt(Config.PROXMOX_PASSWORD)
        await db.execute("""
            INSERT OR IGNORE INTO nodes (id, host, ssh_port, username, encrypted_password, tmate_user, tmate_host)
            VALUES (1, ?, ?, ?, ?, ?, ?)
        """, (Config.PROXMOX_HOST, Config.SSH_PORT, Config.PROXMOX_USERNAME, encrypted_pass, Config.TMATE_USER, Config.TMATE_HOST))
        
        await db.commit()

async def get_db():
    return await aiosqlite.connect(Config.DB_PATH)
