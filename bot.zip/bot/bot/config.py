import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    BOT_TOKEN = os.getenv("BOT_TOKEN")
    try:
        ADMIN_IDS = [int(id.strip()) for id in os.getenv("ADMIN_IDS", "").split(",") if id.strip()]
    except ValueError:
        ADMIN_IDS = []
    ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")
    OXAPAY_API_KEY = os.getenv("OXAPAY_API_KEY")
    try:
        CONSOLE_PORT = int(os.getenv("CONSOLE_PORT", 4004))
    except (ValueError, TypeError):
        CONSOLE_PORT = 4004
    CONSOLE_HOST = os.getenv("CONSOLE_HOST", "localhost")
    CONSOLE_SECRET = os.getenv("CONSOLE_SECRET", "supersecret")
    DB_PATH = os.getenv("DB_PATH", "vps_bot.db")

    PLANS = {
        "Small": {"cpu": 1, "ram": 1024, "disk": 10, "price": 5.0},
        "Medium": {"cpu": 2, "ram": 2048, "disk": 20, "price": 10.0},
        "Large": {"cpu": 4, "ram": 4096, "disk": 40, "price": 20.0},
    }

    IPV6_PRICE = 1.0
