import shlex
from bot.node_manager import NodeManager

class LXCManager:
    @staticmethod
    async def create_lxc(node, vps_id, plan, ipv6_enabled, root_password, template: str = None):
        lxc_id = vps_id + 1000  # Offset to avoid conflicts with existing Proxmox CTs

        safe_pass = shlex.quote(root_password)

        if not template:
            template = "local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst"

        net0 = "name=eth0,bridge=vmbr0,ip=dhcp"
        if ipv6_enabled:
            net0 += ",ip6=auto"

        cmd = (
            f"pct create {lxc_id} {template} "
            f"--hostname vps-{lxc_id} "
            f"--net0 {net0} "
            f"--memory {plan['ram']} "
            f"--cores {plan['cpu']} "
            f"--rootfs local-lvm:{plan['disk']} "
            f"--password {safe_pass} "
            f"--onboot 1 --unprivileged 1"
        )

        stdout, stderr, code = await NodeManager.run_command(node, cmd)
        # stderr is merged into stdout by bash wrapper; check both
        output = (stdout or "") + (stderr or "")
        if code != 0:
            return False, output.strip() or f"pct create exited with code {code} (no output)"

        # Start container
        await NodeManager.run_command(node, f"pct start {lxc_id}")

        return True, lxc_id



    @staticmethod
    async def start_lxc(node, lxc_id):
        return await NodeManager.run_command(node, f"pct start {lxc_id}")

    @staticmethod
    async def stop_lxc(node, lxc_id):
        return await NodeManager.run_command(node, f"pct stop {lxc_id}")

    @staticmethod
    async def restart_lxc(node, lxc_id):
        return await NodeManager.run_command(node, f"pct reboot {lxc_id}")

    @staticmethod
    async def delete_lxc(node, lxc_id):
        # Stop first then destroy
        await NodeManager.run_command(node, f"pct stop {lxc_id}")
        return await NodeManager.run_command(node, f"pct destroy {lxc_id}")

    @staticmethod
    async def get_status(node, lxc_id):
        stdout, stderr, code = await NodeManager.run_command(node, f"pct status {lxc_id}")
        if code == 0:
            return stdout.strip().split(": ")[1] # e.g., "status: running"
        return "unknown"

    @staticmethod
    async def get_internal_ip(node, lxc_id):
        # This is tricky as we need to wait for DHCP.
        # We can use pct exec to run 'hostname -I'
        stdout, stderr, code = await NodeManager.run_command(node, f"pct exec {lxc_id} -- hostname -I")
        if code == 0 and stdout:
            return stdout.split()[0]
        return None
