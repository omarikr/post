import discord
from datetime import datetime

class Embeds:
    @staticmethod
    def success(title: str, description: str) -> discord.Embed:
        embed = discord.Embed(
            title=f"✅ {title}",
            description=description,
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        return embed

    @staticmethod
    def error(title: str, description: str) -> discord.Embed:
        embed = discord.Embed(
            title=f"❌ {title}",
            description=description,
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        return embed

    @staticmethod
    def info(title: str, description: str) -> discord.Embed:
        embed = discord.Embed(
            title=f"ℹ️ {title}",
            description=description,
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        return embed

    @staticmethod
    def vps_list(vps_list: list) -> discord.Embed:
        embed = discord.Embed(
            title="🖥️ Your VPS Instances",
            color=discord.Color.gold(),
            timestamp=datetime.now()
        )
        for vps in vps_list:
            embed.add_field(
                name=f"VPS #{vps['lxc_id']} ({vps['plan_name']})",
                value=f"Status: {vps['status']}\nCPU: {vps['cpu']} Cores\nRAM: {vps['ram']}MB\nDisk: {vps['disk']}GB",
                inline=False
            )
        return embed
