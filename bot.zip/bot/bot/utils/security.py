from cryptography.fernet import Fernet
from passlib.hash import bcrypt
from bot.config import Config

class Security:
    _fernet = Fernet(Config.ENCRYPTION_KEY.encode()) if Config.ENCRYPTION_KEY else None

    @staticmethod
    def encrypt(data: str) -> str:
        if not Security._fernet:
            raise ValueError("Encryption key not configured")
        return Security._fernet.encrypt(data.encode()).decode()

    @staticmethod
    def decrypt(token: str) -> str:
        if not Security._fernet:
            raise ValueError("Encryption key not configured")
        return Security._fernet.decrypt(token.encode()).decode()

    @staticmethod
    def hash_password(password: str) -> str:
        return bcrypt.hash(password)

    @staticmethod
    def verify_password(password: str, hashed: str) -> bool:
        return bcrypt.verify(password, hashed)
