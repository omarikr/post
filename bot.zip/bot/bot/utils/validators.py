import re

class Validators:
    @staticmethod
    def is_valid_password(password: str) -> bool:
        # Minimum 8 chars, at least one letter and one number
        return len(password) >= 8 and any(c.isdigit() for c in password) and any(c.isalpha() for c in password)

    @staticmethod
    def sanitize_input(text: str) -> str:
        # Basic sanitization
        return re.sub(r'[^\w\s\.-]', '', text)

    @staticmethod
    def is_admin(user_id: int, admin_ids: list) -> bool:
        return user_id in admin_ids
