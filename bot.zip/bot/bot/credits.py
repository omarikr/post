from bot.database import get_db

class CreditsManager:
    @staticmethod
    async def get_balance(user_id: int) -> float:
        db = await get_db()
        async with db.execute("SELECT credits FROM users WHERE id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return row[0]
            else:
                await db.execute("INSERT INTO users (id, credits) VALUES (?, ?)", (user_id, 0.0))
                await db.commit()
                return 0.0

    @staticmethod
    async def add_credits(user_id: int, amount: float):
        db = await get_db()
        await db.execute("UPDATE users SET credits = credits + ? WHERE id = ?", (amount, user_id))
        await db.commit()

    @staticmethod
    async def deduct_credits(user_id: int, amount: float) -> bool:
        db = await get_db()
        balance = await CreditsManager.get_balance(user_id)
        if balance >= amount:
            await db.execute("UPDATE users SET credits = credits - ? WHERE id = ?", (amount, user_id))
            await db.commit()
            return True
        return False

    @staticmethod
    async def log_transaction(user_id: int, amount: float, currency: str, status: str, txid: str = None):
        db = await get_db()
        import uuid
        trans_id = str(uuid.uuid4())
        await db.execute(
            "INSERT INTO transactions (id, user_id, amount, currency, status, txid) VALUES (?, ?, ?, ?, ?, ?)",
            (trans_id, user_id, amount, currency, status, txid)
        )
        await db.commit()
