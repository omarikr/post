import sys
import os
import discord
import multiprocessing
import uvicorn
import asyncio
import logging
from discord.ext import commands

# Fix path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.config import Config
from bot.database import init_db

# Configure logging
logging_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
logging.basicConfig(level=logging.INFO, format=logging_format)
logger = logging.getLogger("VPSBot")

class MyBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        # Setting help_command=None to allow our custom hybrid help command
        super().__init__(command_prefix="!", intents=intents, help_command=None)

    async def setup_hook(self):
        # Initialize Database
        await init_db()
        
        # Load Cogs
        cogs = ["bot.cogs.vps", "bot.cogs.payments", "bot.cogs.admin"]
        for cog in cogs:
            try:
                # Need to use the full path including 'bot.' if running from root
                await self.load_extension(cog)
                logger.info(f"Loaded extension: {cog}")
            except Exception as e:
                logger.error(f"Failed to load extension {cog}: {e}")

        # Sync application commands
        await self.tree.sync()
        logger.info("Synced application commands.")

    async def on_ready(self):
        logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        logger.info("Bot is ready!")

def run_console_server():
    """Run uvicorn in a separate process. Retry once if port is already in use."""
    import time, socket
    from bot.console_server import app

    # Wait up to 5 s for the port to become free (handles stale processes dying)
    for attempt in range(5):
        with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("::1", Config.CONSOLE_PORT))
                break  # port is free
            except OSError:
                if attempt < 4:
                    time.sleep(1)
                else:
                    print(f"[console] Port {Config.CONSOLE_PORT} still in use after 5s — skipping console server start.", flush=True)
                    return

    try:
        uvicorn.run(app, host=Config.CONSOLE_HOST, port=Config.CONSOLE_PORT, log_level="info")
    except OSError as e:
        print(f"[console] Failed to bind port {Config.CONSOLE_PORT}: {e}", flush=True)

async def main():
    bot = MyBot()
    async with bot:
        await bot.start(Config.BOT_TOKEN)

if __name__ == "__main__":
    # Start Web Server in a separate process
    # On Windows, multiprocessing requires if __name__ == "__main__"
    web_process = multiprocessing.Process(target=run_console_server, daemon=True)
    web_process.start()
    
    import logging # Re-importing inside __main__ to be safe
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        web_process.terminate()
