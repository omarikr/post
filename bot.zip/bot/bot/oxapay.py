import aiohttp
import logging
from bot.config import Config

class OxaPayClient:
    API_URL = "https://api.oxapay.com/merchants/request"

    @staticmethod
    async def create_payment(user_id: int, amount: float, currency: str = "USD"):
        # Correct payload for OxaPay Request API
        payload = {
            "merchant": Config.OXAPAY_API_KEY, # In v1 it might be key, checking specific endpoint
            "amount": amount,
            "currency": currency,
            "lifeTime": 30,
            "feePaidByPayer": 0,
            "underPaidCover": 0,
            "callbackUrl": f"http://{Config.CONSOLE_HOST}:{Config.CONSOLE_PORT}/api/callback/oxapay",
            "description": f"Deposit for User {user_id}",
            "orderId": f"{user_id}"
        }
        
        # OxaPay usually expects form data or JSON.
        # Let's try the correct merchant request endpoint.
        # Based on OxaPay docs: POST https://api.oxapay.com/merchants/request
        # Body: {"merchant": "API_KEY", "amount": ..., ...}
        
        async with aiohttp.ClientSession() as session:
            try:
                # Use json=payload for application/json
                async with session.post("https://api.oxapay.com/merchants/request", json=payload) as resp:
                    if resp.status != 200:
                        logging.error(f"OxaPay HTTP Error: {resp.status}")
                        return None
                    
                    data = await resp.json()
                    # Check "result"
                    if data.get("result") == 100:
                        return data # Contains payLink, trackId
                    else:
                        logging.error(f"OxaPay API Error: {data}")
                        return None
            except Exception as e:
                logging.error(f"OxaPay Connection Error: {e}")
                return None

    @staticmethod
    async def verify_payment(track_id: int):
        # Verification logic would go here if using poll instead of callback
        # URL: https://api.oxapay.com/merchants/get/payment
        pass
        return False
