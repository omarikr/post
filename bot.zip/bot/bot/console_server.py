from fastapi import FastAPI, WebSocket, Request, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import jwt
import asyncio
import asyncssh
import logging
from bot.config import Config
from bot.database import get_db
from bot.node_manager import NodeManager
from bot.lxc_manager import LXCManager
from bot.utils.security import Security

app = FastAPI()
templates = Jinja2Templates(directory="bot/web/templates")

async def validate_token(vps_id: int, token: str):
    try:
        payload = jwt.decode(token, Config.CONSOLE_SECRET, algorithms=["HS256"])
        if payload['vps_id'] != vps_id:
            raise HTTPException(status_code=403, detail="Invalid token for this VPS")
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=403, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=403, detail="Invalid token")

@app.get("/console/{vps_id}", response_class=HTMLResponse)
async def get_console(request: Request, vps_id: int, token: str = Query(...)):
    await validate_token(vps_id, token)
    return templates.TemplateResponse("console.html", {"request": request, "vps_id": vps_id, "token": token})

@app.websocket("/ws/console/{vps_id}")
async def websocket_console(websocket: WebSocket, vps_id: int, token: str = Query(...)):
    await websocket.accept()
    
    try:
        payload = await validate_token(vps_id, token)
    except:
        await websocket.close(code=4003)
        return

    db = await get_db()
    async with db.execute("SELECT node_id, lxc_id FROM vps_instances WHERE id = ?", (vps_id,)) as cursor:
        row = await cursor.fetchone()
    
    if not row:
        await websocket.close(code=4004)
        return

    node_id, lxc_id = row
    node = await NodeManager.get_node(db, node_id)
    
    internal_ip = await LXCManager.get_internal_ip(node, lxc_id)
    if not internal_ip:
        await websocket.send_text("\r\n[Error] Could not find container IP. Is it running?\r\n")
        await websocket.close()
        return

    await websocket.send_text("\r\nConnecting to container SSH...\r\n")
    
    try:
        node_pass = Security.decrypt(node['encrypted_password'])
        async with asyncssh.connect(
            node['host'],
            port=node['ssh_port'],
            username=node['username'],
            password=node_pass,
            known_hosts=None
        ) as conn:
            async with conn.create_process(f"pct enter {lxc_id}") as process:
                async def forward_ws_to_ssh():
                    try:
                        while True:
                            data = await websocket.receive_text()
                            process.stdin.write(data)
                    except:
                        process.terminate()

                async def forward_ssh_to_ws():
                    try:
                        while True:
                            data = await process.stdout.read(4096)
                            if not data: break
                            await websocket.send_text(data)
                    except:
                        pass

                await asyncio.gather(forward_ws_to_ssh(), forward_ssh_to_ws())
    except Exception as e:
        await websocket.send_text(f"\r\n[Connection Error] {str(e)}\r\n")
        await websocket.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=Config.CONSOLE_HOST, port=Config.CONSOLE_PORT)
