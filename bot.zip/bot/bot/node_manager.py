import asyncssh
import asyncio
import logging
import re
import uuid
from bot.utils.security import Security

logger = logging.getLogger(__name__)

class NodeManager:
    """
    Manages SSH connections to Proxmox nodes via tmate relay sessions.

    Each node stores:
      - host / ssh_port  : the Proxmox HTTP endpoint (for reference / API; NOT used for SSH)
      - tmate_user       : tmate session token-user  (e.g. PK59vkpjWf8N98bzgyPQpDyuk)
      - tmate_host       : tmate relay host           (e.g. lon1.tmate.io)
      - username         : local unix user on the proxy (usually the tmate token user itself)
      - encrypted_password: NOT used for tmate (tmate auth is token-based); kept for future direct nodes
    """

    # pct create can take 60-90 s; give plenty of room
    SSH_TIMEOUT = 120

    @staticmethod
    async def run_command(node: dict, command: str):
        """
        Run *command* on the Proxmox node via its tmate relay session.
        Returns (stdout, stderr, exit_status).

        HOW TMATE SSH EXEC WORKS
        ─────────────────────────
        tmate's SSH server passes every exec string straight to tmux's own
        command parser — NOT to /bin/sh.  That is why plain shell commands
        like `export PATH=…` give back "Invalid command".

        THE FIX
        ───────
        Wrap the shell code inside tmux's built-in `run-shell` command,
        which IS recognised by tmux's parser.  tmux then forks /bin/sh to
        execute the string and — when called without a -t target — pipes
        the output back through the SSH exec channel's stdout.

        Flow:
          conn.run("run-shell '<shell-code>'")
          ↓  SSH exec → tmate → tmux command parser
          tmux: run-shell '<shell-code>'
          ↓  tmux forks sh -c '<shell-code>'
          sh: runs pct / pveam / … and writes to stdout
          ↓  output piped back through SSH exec channel
          asyncssh: result.stdout  ← clean text, no PTY games
        """
        tmate_user = node.get('tmate_user')
        tmate_host = node.get('tmate_host')

        if not tmate_user or not tmate_host:
            err = "Node has no tmate credentials configured."
            logger.error(err)
            return None, err, 1

        # Use a tmp file so long output never overflows run-shell's pipe buffer.
        tmp = f"/tmp/.bot_{uuid.uuid4().hex[:10]}"

        # Shell code to run on the Proxmox box
        shell_code = (
            f"export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH; "
            f"( {command} ) >{tmp} 2>&1; "
            f"_ec=$?; cat {tmp}; rm -f {tmp}; exit $_ec"
        )

        # Escape single quotes so we can embed shell_code inside run-shell '…'
        # Rule:  every  '  becomes  '\''
        sq_safe = shell_code.replace("'", "'\\''")
        tmux_cmd = f"run-shell '{sq_safe}'"

        try:
            logger.info(f"tmate [{tmate_user}@{tmate_host}] CMD: {command}")
            async with asyncssh.connect(
                tmate_host,
                port=22,
                username=tmate_user,
                known_hosts=None,
                client_keys=None,
                password=None,
                login_timeout=30,
                server_host_key_algs=[
                    'ssh-rsa', 'rsa-sha2-256', 'rsa-sha2-512',
                    'ecdsa-sha2-nistp256', 'ecdsa-sha2-nistp384',
                    'ecdsa-sha2-nistp521', 'ssh-ed25519'
                ],
                agent_path=None,
            ) as conn:
                result = await asyncio.wait_for(
                    conn.run(tmux_cmd, check=False),
                    timeout=NodeManager.SSH_TIMEOUT
                )

            stdout = result.stdout or ""
            stderr = result.stderr or ""
            combined = (stdout + stderr).strip()

            if result.exit_status != 0:
                logger.error(
                    f"tmate CMD failed (exit {result.exit_status}): "
                    f"{combined[:400] or '(no output)'}"
                )
            else:
                logger.debug(f"tmate CMD ok: {combined[:300]}")

            return stdout, stderr, result.exit_status

        except asyncio.TimeoutError:
            err = f"SSH command timed out after {NodeManager.SSH_TIMEOUT}s."
            logger.error(f"Timeout on {tmate_host}: {err}")
            return None, err, 1
        except Exception as e:
            logger.error(f"SSH Error via tmate ({tmate_host}): {e}")
            return None, str(e), 1


    # ------------------------------------------------------------------ #

    #  Template discovery                                                  #
    # ------------------------------------------------------------------ #

    # OS keyword → (friendly prefix, emoji)
    _OS_MAP = [
        ("ubuntu",  "Ubuntu",       "🟠"),
        ("debian",  "Debian",       "🔴"),
        ("centos",  "CentOS",       "🟣"),
        ("fedora",  "Fedora",       "🔵"),
        ("arch",    "Arch Linux",   "🔵"),
        ("alpine",  "Alpine",       "🏔️"),
        ("rockylinux","Rocky Linux","🟢"),
        ("almalinux","AlmaLinux",  "🟢"),
        ("opensuse","openSUSE",     "🟢"),
        ("gentoo",  "Gentoo",       "🟣"),
        ("nixos",   "NixOS",        "❄️"),
        ("turnkey", "TurnKey",      "🔑"),
        ("devuan",  "Devuan",       "🔵"),
        ("kali",    "Kali Linux",   "💀"),
    ]

    @staticmethod
    def _friendly_name(raw_name: str) -> tuple[str, str]:
        """
        Convert a raw template filename like
          'local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst'
        to a friendly label like 'Ubuntu 22.04 (standard)' and pick an emoji.
        """
        # strip storage prefix and path
        fname = raw_name.split("/")[-1]          # ubuntu-22.04-standard_22.04-1_amd64.tar.zst
        fname = re.sub(r'\.tar\.\w+$', '', fname)  # ubuntu-22.04-standard_22.04-1_amd64
        fname = re.sub(r'_amd64$|_arm64$|_x86_64$', '', fname)

        emoji = "🖥️"
        label = fname

        for keyword, pretty, emo in NodeManager._OS_MAP:
            if keyword in fname.lower():
                emoji = emo
                # extract version number – first group of digits+dots after the OS name
                m = re.search(r'[\-_](\d[\d.]+)', fname)
                version = m.group(1) if m else ""
                # extract variant (standard / minimal / etc.)
                parts = re.split(r'[\-_]', fname.lower())
                variants = [p for p in parts if p in ("standard", "minimal", "base", "server", "desktop")]
                variant = f" ({variants[0]})" if variants else ""
                label = f"{pretty} {version}{variant}".strip()
                break

        return label, emoji

    @staticmethod
    async def list_templates(node: dict) -> list[dict]:
        """
        SSH into the node and run `pveam list local` to get all available
        CT templates stored locally.

        Returns a list of dicts:
          { 'value': 'local:vztmpl/...', 'label': 'Ubuntu 22.04 (standard)', 'emoji': '🟠' }
        capped at 25 entries (Discord select limit).
        """
        stdout, stderr, code = await NodeManager.run_command(
            node, "pveam list local 2>/dev/null || pvesm list local --content vztmpl 2>/dev/null"
        )

        templates = []
        if not stdout or code != 0:
            logger.warning(f"pveam list returned code={code}: {stderr}")
            return templates

        for line in stdout.strip().splitlines():
            line = line.strip()
            # pveam output rows look like:
            #   local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst   219.86MB
            if not line or line.startswith("Name") or "vztmpl" not in line:
                continue
            parts = line.split()
            raw = parts[0]   # local:vztmpl/...
            label, emoji = NodeManager._friendly_name(raw)
            templates.append({"value": raw, "label": label, "emoji": emoji})

        # Discord select menus max 25 options
        return templates[:25]

    # ------------------------------------------------------------------ #
    #  DB helpers                                                          #
    # ------------------------------------------------------------------ #

    @staticmethod
    async def get_node(db, node_id: int):
        async with db.execute("SELECT * FROM nodes WHERE id = ?", (node_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return NodeManager._row_to_dict(row)
        return None

    @staticmethod
    async def get_all_nodes(db):
        async with db.execute("SELECT * FROM nodes") as cursor:
            rows = await cursor.fetchall()
            return [NodeManager._row_to_dict(r) for r in rows]

    @staticmethod
    def _row_to_dict(row):
        """Map a DB row to a node dict. Columns:
           0:id  1:host  2:ssh_port  3:username  4:encrypted_password
           5:tmate_user  6:tmate_host
        """
        return {
            'id':                 row[0],
            'host':               row[1],
            'ssh_port':           row[2],
            'username':           row[3],
            'encrypted_password': row[4],
            'tmate_user':         row[5] if len(row) > 5 else None,
            'tmate_host':         row[6] if len(row) > 6 else None,
        }
