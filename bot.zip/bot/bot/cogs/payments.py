import discord
from discord.ext import commands
from bot.credits import CreditsManager
from bot.oxapay import OxaPayClient
from bot.utils.embeds import Embeds
from bot.database import get_db

class PaymentsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="balance", description="Check your credit balance")
    async def balance(self, ctx: commands.Context):
        bal = await CreditsManager.get_balance(ctx.author.id)
        await ctx.send(embed=Embeds.info("Balance", f"Your current balance is: **${bal:.2f}**"))

    @commands.hybrid_command(name="deposit", description="Deposit credits using OxaPay (Crypto)")
    async def deposit(self, ctx: commands.Context, amount: float = None):
        if amount is None:
            return await ctx.send(embed=Embeds.error("Missing Argument", "Please specify an amount. Example: `!deposit 10`"), ephemeral=True)
        
        if amount < 1.0:
            return await ctx.send(embed=Embeds.error("Invalid Amount", "Minimum deposit is $1.00"), ephemeral=True)
        
        await ctx.defer(ephemeral=True)
        resp = await OxaPayClient.create_payment(ctx.author.id, amount)
        
        if resp and resp.get("paylink"):
            await CreditsManager.log_transaction(ctx.author.id, amount, "USD", "pending", resp.get("trackId"))
            await ctx.send(embed=Embeds.success("Payment Created", f"Click the link below to pay with Crypto (OxaPay):\n\n[Pay Now]({resp['paylink']})\n\nCredits will be added automatically once confirmed."), ephemeral=True)
        else:
            await ctx.send(embed=Embeds.error("Payment Error", "Failed to contact payment provider. Please try again later."), ephemeral=True)

    @commands.hybrid_command(name="transactions", description="View your 10 most recent transactions")
    async def transactions(self, ctx: commands.Context):
        db = await get_db()
        async with db.execute("SELECT amount, currency, status, created_at FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10", (ctx.author.id,)) as cursor:
            rows = await cursor.fetchall()
        
        if not rows:
            return await ctx.send(embed=Embeds.info("Transactions", "No transaction history found."))
        
        desc = ""
        for row in rows:
            desc += f"`{row[3]}`: **${row[0]} {row[1]}** - {row[2].upper()}\n"
        
        await ctx.send(embed=Embeds.info("Recent Transactions", desc))

async def setup(bot):
    await bot.add_cog(PaymentsCog(bot))
