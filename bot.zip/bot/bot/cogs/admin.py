import discord
from discord.ext import commands
from bot.config import Config
from bot.database import get_db
from bot.node_manager import NodeManager
from bot.credits import CreditsManager
from bot.utils.embeds import Embeds
from bot.utils.security import Security

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="admin-addnode", description="Add a new Proxmox node")
    async def admin_addnode(
        self,
        ctx: commands.Context,
        host: str,
        username: str,
        password: str,
        tmate_user: str,
        tmate_host: str = "lon1.tmate.io",
        port: int = 22
    ):
        """
        Add a Proxmox node.
        - host        : HTTP/public host of the Proxmox server (stored for reference)
        - username    : SSH username on Proxmox (root)
        - password    : SSH password on Proxmox (encrypted at rest)
        - tmate_user  : tmate session token (the part before @)
        - tmate_host  : tmate relay server (default: lon1.tmate.io)
        - port        : kept for reference (default 22)
        """
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)

        db = await get_db()
        encrypted_pass = Security.encrypt(password)
        await db.execute(
            "INSERT INTO nodes (host, ssh_port, username, encrypted_password, tmate_user, tmate_host) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (host, port, username, encrypted_pass, tmate_user, tmate_host)
        )
        await db.commit()
        await ctx.send(
            embed=Embeds.success(
                "Node Added",
                f"**Host:** {host}\n**tmate relay:** `{tmate_user}@{tmate_host}`"
            ),
            ephemeral=True
        )

    @commands.hybrid_group(name="admin-credit", description="Manage user credits")
    async def admin_credit(self, ctx: commands.Context):
        if ctx.invoked_subcommand is None:
            await ctx.send("Use `/admin-credit add` or `/admin-credit remove`", ephemeral=True)

    @admin_credit.command(name="add", description="Add credits to a user")
    async def credit_add(self, ctx: commands.Context, user: discord.User, amount: float):
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)
        await CreditsManager.add_credits(user.id, amount)
        await ctx.send(embed=Embeds.success("Credits Added", f"Added ${amount} to {user.mention}'s account."), ephemeral=True)

    @admin_credit.command(name="remove", description="Remove credits from a user")
    async def credit_remove(self, ctx: commands.Context, user: discord.User, amount: float):
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)

        current_bal = await CreditsManager.get_balance(user.id)
        new_bal = max(0.0, current_bal - amount)

        db = await get_db()
        await db.execute("UPDATE users SET balance = ? WHERE id = ?", (new_bal, user.id))
        await db.execute(
            "INSERT INTO transactions (user_id, amount, currency, status, payment_id) VALUES (?, ?, ?, ?, ?)",
            (user.id, -amount, "USD", "admin_remove", "admin")
        )
        await db.commit()
        await ctx.send(embed=Embeds.success("Credits Removed", f"Removed ${amount} from {user.mention}. New Balance: ${new_bal:.2f}"), ephemeral=True)

    @commands.hybrid_command(name="admin-listvps", description="List all VPS instances in the system")
    async def admin_listvps(self, ctx: commands.Context):
        if ctx.author.id not in Config.ADMIN_IDS:
            return await ctx.send("Only admins can use this command.", ephemeral=True)

        db = await get_db()
        async with db.execute("SELECT id, user_id, lxc_id, plan_name, status FROM vps_instances") as cursor:
            rows = await cursor.fetchall()

        embed = discord.Embed(title="Global VPS Instances", color=discord.Color.dark_grey())
        if not rows:
            embed.description = "No VPS instances found."
        for row in rows:
            embed.add_field(
                name=f"ID: {row[0]} | User: {row[1]}",
                value=f"LXC: {row[2]} | Plan: {row[3]} | Status: {row[4]}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(AdminCog(bot))
